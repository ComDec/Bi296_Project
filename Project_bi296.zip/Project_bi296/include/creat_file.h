#ifndef __creat_file__
#define __creat_file__

void creat_file(char *filename);

#endif
