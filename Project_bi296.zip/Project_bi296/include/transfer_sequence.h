#ifndef __transfer_sequence__
#define __transfer_sequence__

void transfer_sequence(char *filename, char *output);
#endif
