#ifndef __count_char__
#define __count_char__

int count_char(char *filename);

#endif
