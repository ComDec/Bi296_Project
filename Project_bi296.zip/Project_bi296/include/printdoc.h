#ifndef __printdoc__
#define __printdoc__

void printdoc(char *filename);

#endif
