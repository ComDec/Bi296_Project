#ifndef __extract_sequence__
#define __extract_sequence__

void extract_sequence(char *filename, char *output);

#endif
